import math

def getPerimeter(radius):
    perimeter = 2*math.pi*radius
    return perimeter

def getArea(radius):
    area = math.pi*radius*radius
    return area


