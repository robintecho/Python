def getPerimeter(length,breadth,height):
    perimeter = 4*(length+breadth+height)
    return perimeter

def getArea(length,breadth,height):
    area = 2*((length*breadth)+(length*height)+(breadth*height))
    return area

