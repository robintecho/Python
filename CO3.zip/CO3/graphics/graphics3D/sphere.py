import math

def getPerimeter(radius):
    perimeter = 2*math.pi*radius
    return perimeter

def getArea(radius):
    area = 4*math.pi*radius*radius
    return area


