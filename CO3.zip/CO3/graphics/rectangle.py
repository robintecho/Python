def getPerimeter(length,breadth):
    perimeter = 2*(length+breadth)
    return perimeter


def getArea(length,breadth):
    area = length*breadth
    return area


